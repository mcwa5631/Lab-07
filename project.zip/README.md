<h1><a href="https://github.com/rhildred/CP202Assignment5" target="_blank">Material Design One Page HTML Possible Template for CP202 Assignment 5</a></h1>
<p>MD One page template is fully responsive and free to use. This HTML template is based on <a href="http://materializecss.com/" target="_blank">Materialize</a>, a CSS Framework based on Material Design.</p>
<a href="http://rhildred.github.io/CP202Assignment5" target="_blank">View Demo</a>
<br/>

## Video Describing A possible workflow for getting this on your own gh-pages.

<iframe width="560" height="315" src="https://www.youtube.com/embed/cRsot8Qty4c?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

## Video Describing how to Submit your website in mylearningspace

<iframe width="560" height="315" src="https://www.youtube.com/embed/haiNUEGmD8I?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

<h3>Screenshots</h3>
<img src="https://m1.behance.net/rendition/modules/155787441/disp/f7713eb665752f2da380ec8f7a3cdcae.png" height="300px"/> <img src="https://m1.behance.net/rendition/modules/155787447/disp/e546efd70f5b46e45829e0da79375243.png" height="300px"/>
<br/>
<a href="https://www.behance.net/gallery/23484793/Material-Design-One-Page-Template" target="_blank">View More Screens</a>
<h3>Platforms used</h3>
HTML, CSS, JS

<h3>Resources</h3>
<ul>
    <li><a href="http://materializecss.com/" target="_blank">Materialize</a></li>
    <li><a href="http://www.materialpalette.com/" target="_blank">Material Design Colors</a></li>
</ul>

<h2>License</h2>
Material Design One Page HTML Template is licensed under the <a href="http://sam.zoy.org/wtfpl/">WTFPL license</a>.
